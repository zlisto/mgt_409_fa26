# Meridian research corpus (student pack)

Local HTML pages that stand in for the public web for **Homework 2**.

## Folders

| Folder | Contents |
|--------|----------|
| `briefing/` | Strategy memo and research goal |
| `corpus/` | HTML pages to index and search |
| `seed/` | Optional starter queries |

Each corpus HTML file includes a `corpus_url` (also shown in the footer) you should treat as that page’s public URL when citing sources.

## How to use

Point your search tool at `corpus/`. Read `briefing/meridian_strategy_memo.md` before you run the agent. Do not invent URLs outside this pack.
