# Meridian Home Goods — Strategy memo (internal)

**To:** Competitive intelligence working group  
**From:** Priya Shah, Head of Strategy  
**Date:** 2026-06-02  
**Re:** Q3 board deck — peer set for DTC furniture

## Who we are

Meridian Home Goods sells mid-market furniture and home décor online, with a small wholesale channel into New England boutiques. Average order value is roughly $420. We compete on design quality at approachable prices, not on ultra-premium Scandinavian positioning and not on rock-bottom marketplace SKUs.

## What leadership needs

For the Q3 board meeting we need a **short competitor brief**:

1. Identify **at least three active peer competitors** in the DTC / direct furniture space (brands that design and sell their own furniture to consumers online).
2. For each peer: positioning in one sentence, primary URL (use the corpus page URL / path we indexed), and source pages you actually read.
3. Call out **risks** to Meridian (pricing pressure, shipping promises, channel shifts).
4. Be explicit about what you **verified in sources** vs what the model **inferred**.

## Constraints

- Prefer primary sources (About, press, funding notices) over gossip blogs.
- If two sources conflict, say so — do not silently average them.
- Do not treat Meridian as a competitor to itself.
- Marketplaces that host many brands are a different animal from DTC brand peers; label them clearly if you mention them.
- Companies that have **exited** consumer furniture should not appear as active peers unless you clearly mark them as exited.

## Pack note

This homework uses a **local research corpus** (HTML pages in `corpus/`) that stands in for the public web so everyone gets the same documents. Your search tool should index and query that folder.
