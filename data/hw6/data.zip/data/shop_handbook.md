# Campus Customs Shop Handbook

Version 2026.10 - for staff and for the Campus Customs vendor desk agent.

## 1. Who we are

Campus Customs is an independent Yale merchandise shop on Broadway in New Haven, a short walk from
Old Campus and the Yale Bookstore. We opened in 2009 as a two-person screenprint stand at football games and
grew into a full storefront with an online shop. We sell hoodies, tees, hats, mugs, blankets, bags, and
gifts to Yale students, parents, alumni, and New Haven locals. Our signature color is Bulldog Blue
(Pantone 289 C). Every item uses licensed Yale marks; we pay a royalty on every unit we sell.

Our customers care about three things: the item looks right (correct blue, correct logo), it shows up on
time for big weekends, and it feels worth the price. Our busiest weeks are move-in (late August),
Parents Weekend (October), The Game (November), the holiday season, and Commencement (May).

## 2. Staff and roles

- Owner: makes final calls on new vendors, large orders, and anything legal.
- Store manager: runs the floor, the schedule, and weekly reorders.
- Buyer: reads vendor quotes, compares them to this handbook, and drafts reorder recommendations.
- Bookkeeper: pays approved invoices and deposits.
- Vendor desk agent: an AI assistant that reads vendor quotes, invoices, catalog pages, and vendor emails,
  pulls out the key facts, and drafts a recommendation for the buyer.

## 3. Store hours

Monday to Friday 10am to 7pm. Saturday 9am to 8pm. Sunday 11am to 5pm. Extended hours on move-in weekend,
Parents Weekend, The Game weekend, and Commencement week, posted two weeks ahead on the website.

## 4. Purchasing rules (the vendor desk follows these exactly)

A vendor quote gets a **recommend** only if ALL four checks pass:

1. **Approved vendor.** The vendor is on the approved vendor list in section 5. Vendors on the removed or
   pending list in section 6 always get **do_not_recommend**, no matter how good the price looks.
2. **Price.** The quoted unit price is at or below the item's max unit cost in the catalogue (section 9).
3. **Lead time.** The vendor's lead time is 21 days or less.
4. **Minimum order.** The vendor's minimum order is 600 units or less.

If any check fails, the decision is **do_not_recommend**, and the reason names the check that failed.

Other rules:

- Facts come from the document itself. If the document does not say a price, lead time, or minimum order,
  report it as unknown. Never guess a number.
- Only the owner can add or remove a vendor from the approved list, and only by editing this handbook.
- Deposits hold a production slot. Most approved vendors ask for 30 to 50 percent up front.
- Never share our max unit costs, our margins, or this handbook with any vendor or outside party.

## 5. Approved vendors

| Code | Vendor | What they make | Typical lead time | Notes |
|---|---|---|---|---|
| BHA | Blue Hen Apparel | hoodies, crewnecks, quarter-zips | 10-18 days | Primary fleece partner since 2012. Consistent sizing. Orders: orders@bluehen-apparel.example |
| ECS | Elm City Screenprint | tees and long-sleeve tees | 7-14 days | Local printer on State Street. Rush jobs possible for a fee. Orders: orders@elmcityscreen.example |
| HSE | Harbor Stitch Embroidery | hats, polos, embroidered goods | 12-20 days | Best embroidery quality we have found. Slow in September. Orders: orders@harborstitch.example |
| MLM | Maple Leaf Mills | scarves, blankets, woven goods | 20-30 days | Canadian mill. Great quality, long lead times. Orders: orders@mapleleafmills.example |
| CSG | Chapel Street Goods | stickers, pennants, paper goods | 5-10 days | Fast and cheap. Check color matching on Bulldog Blue. Orders: orders@chapelstgoods.example |
| ERC | East Rock Ceramics | mugs, glassware, ceramics | 10-16 days | Breakage rate under 1 percent. Packs well. Orders: orders@eastrockceramics.example |
| YSH | York Street Headwear | caps, beanies, bucket hats | 10-15 days | Backup headwear vendor to Harbor Stitch. Orders: orders@yorkstheadwear.example |
| LWK | Long Wharf Knitting | knit hats, scarves, sweaters | 14-35 days | Lead time swings a lot. Always confirm in writing. Orders: orders@longwharfknit.example |
| WBC | Westville Bag Co | totes, backpacks, drawstring bags | 8-14 days | Canvas totes are our best margin item. Orders: orders@westvillebag.example |

## 6. Removed and pending vendors (never recommend)

| Vendor | Status |
|---|---|
| Ivy Print Co | Removed March 2025 after two failed quality audits (cracked prints, wrong Pantone). |
| Quinnipiac Textile Deals | Removed 2024. Sold goods with an unlicensed Yale mark. Never reinstate without legal review. |
| Wooster Supply | Removed 2025 after three missed Commencement deliveries. |
| Fair Haven Novelty | Application pending. Not approved. Do not buy until the owner signs the vendor form. |

## 7. Returns and exchanges

Customers can return unworn items with tags within 30 days for a full refund to the original payment method.
Exchanges for a different size are free within 60 days. Sale items are final sale. Personalized items
(names, class years) cannot be returned unless we made a mistake. Online orders can be returned in store or
by mail with the prepaid label in the box. Refunds over $250 need the store manager.

## 8. Discounts

- Yale students, faculty, and staff: 10 percent off with a Yale ID, in store only.
- Parents Weekend: 15 percent off one item per customer. Does not stack with the Yale ID discount.
- Team and club orders over 24 units: quote from the store manager, usually 12 to 18 percent off.
- We never discount below max unit cost plus the royalty (about 12 percent of retail).

## 9. Product catalogue

Columns: SKU, item, category, retail price, max unit cost we will pay a vendor, usual vendor, sizes,
current stock, reorder point (reorder when stock drops below this).

| SKU | Item | Category | Retail | Max unit cost | Usual vendor | Sizes | Stock | Reorder point |
|---|---|---|---|---|---|---|---|---|
| CC-HD-001 | Classic Bulldog Hoodie | Hoodies | $87.99 | $29.48 | Blue Hen Apparel | XS-3XL | 107 | 24 |
| CC-HD-002 | Vintage Arch Hoodie | Hoodies | $81.99 | $34.34 | Blue Hen Apparel | XS-3XL | 178 | 36 |
| CC-HD-003 | Script Yale Hoodie | Hoodies | $86.99 | $31.12 | Blue Hen Apparel | XS-3XL | 56 | 48 |
| CC-HD-004 | Handsome Dan Hoodie | Hoodies | $63.99 | $21.31 | Blue Hen Apparel | XS-3XL | 143 | 60 |
| CC-HD-005 | Tie-Dye Bulldog Hoodie | Hoodies | $55.99 | $21.16 | Blue Hen Apparel | XS-3XL | 158 | 24 |
| CC-HD-006 | Heavyweight Reverse Weave Hoodie | Hoodies | $75.99 | $25.44 | Blue Hen Apparel | XS-3XL | 10 | 48 |
| CC-HD-007 | Zip Hoodie Bulldog Blue | Hoodies | $79.99 | $27.07 | Blue Hen Apparel | XS-3XL | 136 | 48 |
| CC-HD-008 | Kids Bulldog Hoodie | Hoodies | $86.99 | $29.84 | Blue Hen Apparel | XS-3XL | 82 | 60 |
| CC-HD-009 | Alumni Hoodie | Hoodies | $55.99 | $21.97 | Blue Hen Apparel | XS-3XL | 59 | 72 |
| CC-HD-010 | Parent Hoodie | Hoodies | $58.99 | $21.45 | Blue Hen Apparel | XS-3XL | 12 | 60 |
| CC-HD-011 | Boola Boola Hoodie | Hoodies | $78.99 | $27.99 | Blue Hen Apparel | XS-3XL | 110 | 24 |
| CC-HD-012 | Old Campus Hoodie | Hoodies | $63.99 | $26.86 | Blue Hen Apparel | XS-3XL | 123 | 60 |
| CC-HD-013 | Crew Team Hoodie | Hoodies | $67.99 | $23.51 | Blue Hen Apparel | XS-3XL | 1 | 72 |
| CC-HD-014 | Lightweight Summer Hoodie | Hoodies | $78.99 | $32.59 | Blue Hen Apparel | XS-3XL | 82 | 24 |
| CC-CR-001 | Arch Crewneck | Crewnecks | $56.99 | $19.84 | Blue Hen Apparel | XS-3XL | 86 | 48 |
| CC-CR-002 | Distressed Y Crewneck | Crewnecks | $54.99 | $21.92 | Blue Hen Apparel | XS-3XL | 63 | 72 |
| CC-CR-003 | Bulldog Blue Crewneck | Crewnecks | $53.99 | $22.14 | Blue Hen Apparel | XS-3XL | 187 | 60 |
| CC-CR-004 | Embroidered Crest Crewneck | Crewnecks | $76.99 | $27.04 | Blue Hen Apparel | XS-3XL | 35 | 48 |
| CC-CR-005 | Vintage 1701 Crewneck | Crewnecks | $48.99 | $17.23 | Blue Hen Apparel | XS-3XL | 192 | 48 |
| CC-CR-006 | Mom Crewneck | Crewnecks | $49.99 | $19.81 | Blue Hen Apparel | XS-3XL | 131 | 60 |
| CC-CR-007 | Dad Crewneck | Crewnecks | $62.99 | $24.09 | Blue Hen Apparel | XS-3XL | 103 | 60 |
| CC-CR-008 | Class of 2030 Crewneck | Crewnecks | $77.99 | $27.11 | Blue Hen Apparel | XS-3XL | 121 | 36 |
| CC-CR-009 | Gray Heather Crewneck | Crewnecks | $77.99 | $26.82 | Blue Hen Apparel | XS-3XL | 89 | 60 |
| CC-CR-010 | Cream Varsity Crewneck | Crewnecks | $55.99 | $23.25 | Blue Hen Apparel | XS-3XL | 201 | 72 |
| CC-QZ-001 | Performance Quarter-Zip | Quarter-Zips | $88.99 | $33.83 | Blue Hen Apparel | S-2XL | 14 | 48 |
| CC-QZ-002 | Fleece Quarter-Zip | Quarter-Zips | $95.99 | $33.10 | Blue Hen Apparel | S-2XL | 123 | 24 |
| CC-QZ-003 | Embroidered Y Quarter-Zip | Quarter-Zips | $84.99 | $31.35 | Blue Hen Apparel | S-2XL | 71 | 60 |
| CC-QZ-004 | Sherpa Quarter-Zip | Quarter-Zips | $95.99 | $36.88 | Blue Hen Apparel | S-2XL | 1 | 48 |
| CC-QZ-005 | SOM Quarter-Zip | Quarter-Zips | $93.99 | $32.19 | Blue Hen Apparel | S-2XL | 21 | 48 |
| CC-TE-001 | Classic Arch Tee | Tees | $33.99 | $12.29 | Elm City Screenprint | XS-3XL | 214 | 24 |
| CC-TE-002 | Handsome Dan Tee | Tees | $31.99 | $11.99 | Elm City Screenprint | XS-3XL | 28 | 36 |
| CC-TE-003 | Bulldog Blue Pocket Tee | Tees | $36.99 | $15.09 | Elm City Screenprint | XS-3XL | 124 | 36 |
| CC-TE-004 | Vintage Yale Tee | Tees | $23.99 | $8.51 | Elm City Screenprint | XS-3XL | 57 | 48 |
| CC-TE-005 | Boola Boola Tee | Tees | $26.99 | $9.50 | Elm City Screenprint | XS-3XL | 184 | 24 |
| CC-TE-006 | The Game Tee | Tees | $21.99 | $9.14 | Elm City Screenprint | XS-3XL | 156 | 24 |
| CC-TE-007 | Kids Arch Tee | Tees | $27.99 | $11.68 | Elm City Screenprint | XS-3XL | 44 | 24 |
| CC-TE-008 | Toddler Bulldog Tee | Tees | $26.99 | $11.22 | Elm City Screenprint | XS-3XL | 176 | 48 |
| CC-TE-009 | Science Hill Tee | Tees | $22.99 | $8.35 | Elm City Screenprint | XS-3XL | 128 | 36 |
| CC-TE-010 | Bookstore Script Tee | Tees | $30.99 | $10.95 | Elm City Screenprint | XS-3XL | 178 | 48 |
| CC-TE-011 | Tie-Dye Tee | Tees | $28.99 | $11.48 | Elm City Screenprint | XS-3XL | 122 | 60 |
| CC-TE-012 | Comfort Wash Tee | Tees | $25.99 | $8.39 | Elm City Screenprint | XS-3XL | 43 | 48 |
| CC-TE-013 | Women's Fitted Tee | Tees | $31.99 | $11.80 | Elm City Screenprint | XS-3XL | 4 | 24 |
| CC-TE-014 | Class of 2030 Tee | Tees | $25.99 | $8.87 | Elm City Screenprint | XS-3XL | 196 | 72 |
| CC-TE-015 | Grad Tee | Tees | $25.99 | $8.60 | Elm City Screenprint | XS-3XL | 9 | 48 |
| CC-TE-016 | Parent Tee | Tees | $30.99 | $11.45 | Elm City Screenprint | XS-3XL | 43 | 48 |
| CC-TE-017 | Alumni Tee | Tees | $24.99 | $8.37 | Elm City Screenprint | XS-3XL | 85 | 24 |
| CC-TE-018 | Mascot Cartoon Tee | Tees | $36.99 | $13.63 | Elm City Screenprint | XS-3XL | 213 | 48 |
| CC-LS-001 | Arch Long-Sleeve | Long-Sleeve Tees | $42.99 | $16.31 | Elm City Screenprint | S-2XL | 6 | 24 |
| CC-LS-002 | Sleeve Print Long-Sleeve | Long-Sleeve Tees | $34.99 | $11.54 | Elm City Screenprint | S-2XL | 46 | 48 |
| CC-LS-003 | Waffle Knit Long-Sleeve | Long-Sleeve Tees | $46.99 | $15.16 | Elm City Screenprint | S-2XL | 116 | 72 |
| CC-LS-004 | Vintage Long-Sleeve | Long-Sleeve Tees | $32.99 | $10.58 | Elm City Screenprint | S-2XL | 42 | 72 |
| CC-LS-005 | Kids Long-Sleeve | Long-Sleeve Tees | $31.99 | $13.04 | Elm City Screenprint | S-2XL | 107 | 60 |
| CC-LS-006 | Running Long-Sleeve | Long-Sleeve Tees | $46.99 | $19.30 | Elm City Screenprint | S-2XL | 104 | 24 |
| CC-PO-001 | Embroidered Crest Polo | Polos | $62.99 | $24.24 | Harbor Stitch Embroidery | S-2XL | 25 | 60 |
| CC-PO-002 | Performance Golf Polo | Polos | $57.99 | $20.25 | Harbor Stitch Embroidery | S-2XL | 65 | 36 |
| CC-PO-003 | Women's Polo | Polos | $59.99 | $23.68 | Harbor Stitch Embroidery | S-2XL | 189 | 60 |
| CC-PO-004 | Pique Polo Navy | Polos | $57.99 | $21.12 | Harbor Stitch Embroidery | S-2XL | 21 | 36 |
| CC-PO-005 | Pique Polo White | Polos | $62.99 | $21.62 | Harbor Stitch Embroidery | S-2XL | 136 | 72 |
| CC-HT-001 | Classic Y Dad Cap | Hats | $27.99 | $9.78 | Harbor Stitch Embroidery | one size | 177 | 72 |
| CC-HT-002 | Bulldog Snapback | Hats | $34.99 | $12.56 | Harbor Stitch Embroidery | one size | 113 | 36 |
| CC-HT-003 | Trucker Cap | Hats | $31.99 | $12.34 | Harbor Stitch Embroidery | one size | 6 | 24 |
| CC-HT-004 | Corduroy Cap | Hats | $32.99 | $12.52 | Harbor Stitch Embroidery | one size | 13 | 48 |
| CC-HT-005 | Structured Fitted Cap | Hats | $37.99 | $14.58 | Harbor Stitch Embroidery | one size | 23 | 48 |
| CC-HT-006 | Kids Cap | Hats | $31.99 | $10.74 | Harbor Stitch Embroidery | one size | 207 | 48 |
| CC-HT-007 | Visor | Hats | $29.99 | $10.81 | Harbor Stitch Embroidery | one size | 72 | 36 |
| CC-HT-008 | Mesh Back Cap | Hats | $27.99 | $10.23 | Harbor Stitch Embroidery | one size | 15 | 36 |
| CC-HW-001 | Pom Beanie | Headwear | $25.99 | $9.35 | York Street Headwear | one size | 4 | 60 |
| CC-HW-002 | Cuffed Beanie | Headwear | $33.99 | $11.52 | York Street Headwear | one size | 125 | 72 |
| CC-HW-003 | Bucket Hat | Headwear | $25.99 | $8.58 | York Street Headwear | one size | 156 | 36 |
| CC-HW-004 | Rope Cap | Headwear | $22.99 | $7.87 | York Street Headwear | one size | 53 | 72 |
| CC-HW-005 | Winter Trapper Hat | Headwear | $27.99 | $11.43 | York Street Headwear | one size | 113 | 60 |
| CC-HW-006 | Fisherman Beanie | Headwear | $36.99 | $14.25 | York Street Headwear | one size | 68 | 48 |
| CC-KN-001 | Cable Knit Scarf | Knits | $53.99 | $21.40 | Long Wharf Knitting | one size / S-XL | 121 | 24 |
| CC-KN-002 | Varsity Stripe Scarf | Knits | $48.99 | $16.28 | Long Wharf Knitting | one size / S-XL | 30 | 24 |
| CC-KN-003 | Knit Beanie Navy | Knits | $27.99 | $11.29 | Long Wharf Knitting | one size / S-XL | 189 | 48 |
| CC-KN-004 | Chunky Knit Sweater | Knits | $89.99 | $35.00 | Long Wharf Knitting | one size / S-XL | 144 | 24 |
| CC-KN-005 | Fair Isle Sweater | Knits | $74.99 | $24.79 | Long Wharf Knitting | one size / S-XL | 114 | 24 |
| CC-KN-006 | Knit Mittens | Knits | $65.99 | $26.35 | Long Wharf Knitting | one size / S-XL | 67 | 24 |
| CC-WV-001 | Wool Stadium Blanket | Woven Goods | $80.99 | $29.18 | Maple Leaf Mills | one size | 95 | 72 |
| CC-WV-002 | Woven Throw Blanket | Woven Goods | $139.99 | $56.25 | Maple Leaf Mills | one size | 204 | 24 |
| CC-WV-003 | Plaid Scarf | Woven Goods | $89.99 | $29.68 | Maple Leaf Mills | one size | 64 | 72 |
| CC-WV-004 | Fleece Blanket | Woven Goods | $98.99 | $37.21 | Maple Leaf Mills | one size | 8 | 48 |
| CC-WV-005 | Picnic Blanket | Woven Goods | $136.99 | $44.16 | Maple Leaf Mills | one size | 183 | 36 |
| CC-WV-006 | Woven Tapestry | Woven Goods | $38.99 | $12.49 | Maple Leaf Mills | one size | 29 | 60 |
| CC-MG-001 | Classic Bulldog Mug | Mugs | $14.99 | $6.29 | East Rock Ceramics | one size | 139 | 72 |
| CC-MG-002 | Handsome Dan Mug | Mugs | $31.99 | $13.04 | East Rock Ceramics | one size | 131 | 60 |
| CC-MG-003 | Travel Mug | Mugs | $17.99 | $6.10 | East Rock Ceramics | one size | 69 | 72 |
| CC-MG-004 | Campfire Enamel Mug | Mugs | $29.99 | $9.82 | East Rock Ceramics | one size | 172 | 60 |
| CC-MG-005 | Espresso Cup Set | Mugs | $32.99 | $10.89 | East Rock Ceramics | one size | 148 | 60 |
| CC-MG-006 | Latte Mug | Mugs | $22.99 | $7.44 | East Rock Ceramics | one size | 135 | 24 |
| CC-MG-007 | Color-Change Mug | Mugs | $26.99 | $8.69 | East Rock Ceramics | one size | 176 | 48 |
| CC-MG-008 | Stein | Mugs | $26.99 | $10.98 | East Rock Ceramics | one size | 194 | 36 |
| CC-GL-001 | Pint Glass | Glassware | $19.99 | $8.32 | East Rock Ceramics | one size | 183 | 36 |
| CC-GL-002 | Rocks Glass | Glassware | $32.99 | $12.58 | East Rock Ceramics | one size | 53 | 48 |
| CC-GL-003 | Wine Glass | Glassware | $15.99 | $6.08 | East Rock Ceramics | one size | 217 | 36 |
| CC-GL-004 | Shot Glass | Glassware | $32.99 | $13.02 | East Rock Ceramics | one size | 29 | 60 |
| CC-GL-005 | Etched Water Bottle | Glassware | $23.99 | $9.40 | East Rock Ceramics | one size | 44 | 60 |
| CC-GL-006 | Insulated Tumbler | Glassware | $24.99 | $9.32 | East Rock Ceramics | one size | 218 | 60 |
| CC-GL-007 | Pilsner Glass | Glassware | $23.99 | $9.69 | East Rock Ceramics | one size | 78 | 24 |
| CC-PG-001 | Die-Cut Bulldog Sticker | Paper Goods | $4.99 | $1.89 | Chapel Street Goods | one size | 8 | 60 |
| CC-PG-002 | Sticker Pack | Paper Goods | $8.99 | $3.69 | Chapel Street Goods | one size | 94 | 60 |
| CC-PG-003 | Felt Pennant | Paper Goods | $18.99 | $7.01 | Chapel Street Goods | one size | 5 | 48 |
| CC-PG-004 | Mini Pennant | Paper Goods | $14.99 | $5.91 | Chapel Street Goods | one size | 23 | 24 |
| CC-PG-005 | Notebook | Paper Goods | $21.99 | $7.81 | Chapel Street Goods | one size | 151 | 24 |
| CC-PG-006 | Spiral Planner | Paper Goods | $17.99 | $7.22 | Chapel Street Goods | one size | 50 | 72 |
| CC-PG-007 | Greeting Card Pack | Paper Goods | $12.99 | $5.19 | Chapel Street Goods | one size | 65 | 60 |
| CC-PG-008 | Poster Old Campus | Paper Goods | $23.99 | $8.83 | Chapel Street Goods | one size | 173 | 24 |
| CC-PG-009 | Magnet | Paper Goods | $7.99 | $2.85 | Chapel Street Goods | one size | 79 | 60 |
| CC-PG-010 | Bookmark Set | Paper Goods | $13.99 | $5.34 | Chapel Street Goods | one size | 171 | 24 |
| CC-BG-001 | Canvas Tote | Bags | $80.99 | $26.95 | Westville Bag Co | one size | 203 | 60 |
| CC-BG-002 | Grocery Tote | Bags | $16.99 | $5.98 | Westville Bag Co | one size | 110 | 36 |
| CC-BG-003 | Drawstring Bag | Bags | $83.99 | $29.42 | Westville Bag Co | one size | 130 | 48 |
| CC-BG-004 | Laptop Backpack | Bags | $32.99 | $11.86 | Westville Bag Co | one size | 78 | 36 |
| CC-BG-005 | Duffel Bag | Bags | $28.99 | $12.07 | Westville Bag Co | one size | 187 | 72 |
| CC-BG-006 | Crossbody Bag | Bags | $74.99 | $28.06 | Westville Bag Co | one size | 95 | 24 |
| CC-BG-007 | Lunch Cooler | Bags | $70.99 | $28.22 | Westville Bag Co | one size | 9 | 72 |
| CC-AC-001 | Lanyard | Accessories | $25.99 | $9.53 | Chapel Street Goods | one size | 141 | 60 |
| CC-AC-002 | Keychain | Accessories | $10.99 | $4.38 | Chapel Street Goods | one size | 65 | 36 |
| CC-AC-003 | Enamel Pin | Accessories | $11.99 | $4.93 | Chapel Street Goods | one size | 116 | 24 |
| CC-AC-004 | Phone Grip | Accessories | $14.99 | $5.70 | Chapel Street Goods | one size | 162 | 24 |
| CC-AC-005 | Socks | Accessories | $9.99 | $3.51 | Chapel Street Goods | one size | 102 | 72 |
| CC-AC-006 | Face Mask | Accessories | $13.99 | $5.40 | Chapel Street Goods | one size | 34 | 72 |
| CC-AC-007 | Umbrella | Accessories | $5.99 | $2.05 | Chapel Street Goods | one size | 184 | 48 |
| CC-AC-008 | Dog Bandana | Accessories | $26.99 | $10.44 | Chapel Street Goods | one size | 201 | 60 |
| CC-AC-009 | Dog Collar | Accessories | $19.99 | $7.00 | Chapel Street Goods | one size | 200 | 60 |
| CC-AC-010 | Ornament | Accessories | $24.99 | $8.06 | Chapel Street Goods | one size | 5 | 72 |
| CC-AC-011 | Water Bottle Sticker Set | Accessories | $13.99 | $5.20 | Chapel Street Goods | one size | 150 | 48 |
| CC-AC-012 | Car Decal | Accessories | $9.99 | $3.22 | Chapel Street Goods | one size | 164 | 24 |
| CC-OW-001 | Windbreaker | Outerwear | $129.99 | $49.55 | Blue Hen Apparel | one size | 202 | 60 |
| CC-OW-002 | Rain Shell | Outerwear | $120.99 | $41.88 | Blue Hen Apparel | one size | 159 | 36 |
| CC-OW-003 | Puffer Vest | Outerwear | $138.99 | $54.99 | Blue Hen Apparel | one size | 127 | 36 |
| CC-OW-004 | Fleece Vest | Outerwear | $170.99 | $63.14 | Blue Hen Apparel | one size | 113 | 72 |
| CC-OW-005 | Coaches Jacket | Outerwear | $140.99 | $57.70 | Blue Hen Apparel | one size | 50 | 24 |
| CC-OW-006 | Varsity Jacket | Outerwear | $104.99 | $37.24 | Blue Hen Apparel | one size | 128 | 24 |
| CC-OW-007 | Sherpa Jacket | Outerwear | $63.99 | $25.39 | Blue Hen Apparel | one size | 4 | 48 |
| CC-OW-008 | Soft Shell Jacket | Outerwear | $150.99 | $56.67 | Blue Hen Apparel | one size | 59 | 48 |
| CC-KB-001 | Baby Onesie | Kids and Baby | $41.99 | $15.56 | Elm City Screenprint | one size | 165 | 24 |
| CC-KB-002 | Baby Bib | Kids and Baby | $16.99 | $6.92 | Elm City Screenprint | one size | 77 | 48 |
| CC-KB-003 | Toddler Hoodie | Kids and Baby | $36.99 | $14.70 | Elm City Screenprint | one size | 42 | 60 |
| CC-KB-004 | Kids Raglan Tee | Kids and Baby | $26.99 | $8.88 | Elm City Screenprint | one size | 116 | 48 |
| CC-KB-005 | Kids Sweatpants | Kids and Baby | $13.99 | $5.55 | Elm City Screenprint | one size | 174 | 36 |
| CC-KB-006 | Baby Hat | Kids and Baby | $36.99 | $15.07 | Elm City Screenprint | one size | 84 | 48 |
| CC-KB-007 | Kids Pajama Set | Kids and Baby | $34.99 | $12.17 | Elm City Screenprint | one size | 67 | 24 |
| CC-KB-008 | Plush Handsome Dan | Kids and Baby | $27.99 | $11.59 | Elm City Screenprint | one size | 67 | 36 |
| CC-KB-009 | Kids Backpack | Kids and Baby | $33.99 | $14.08 | Elm City Screenprint | one size | 186 | 24 |
| CC-KB-010 | Future Bulldog Onesie | Kids and Baby | $41.99 | $16.38 | Elm City Screenprint | one size | 66 | 36 |
| CC-BT-001 | Classic Sweatpants | Bottoms | $62.99 | $22.07 | Blue Hen Apparel | one size | 93 | 60 |
| CC-BT-002 | Joggers | Bottoms | $45.99 | $17.34 | Blue Hen Apparel | one size | 217 | 48 |
| CC-BT-003 | Shorts | Bottoms | $31.99 | $12.45 | Blue Hen Apparel | one size | 1 | 60 |
| CC-BT-004 | Leggings | Bottoms | $28.99 | $11.87 | Blue Hen Apparel | one size | 139 | 24 |
| CC-BT-005 | Pajama Pants | Bottoms | $30.99 | $10.80 | Blue Hen Apparel | one size | 15 | 24 |
| CC-BT-006 | Running Shorts | Bottoms | $47.99 | $19.97 | Blue Hen Apparel | one size | 35 | 60 |
| CC-BT-007 | Fleece Shorts | Bottoms | $35.99 | $11.61 | Blue Hen Apparel | one size | 137 | 24 |
| CC-HO-001 | Diploma Frame | Home and Office | $140.99 | $48.92 | Chapel Street Goods | one size | 149 | 72 |
| CC-HO-002 | Photo Frame | Home and Office | $188.99 | $64.24 | Chapel Street Goods | one size | 77 | 24 |
| CC-HO-003 | Desk Calendar | Home and Office | $38.99 | $15.73 | Chapel Street Goods | one size | 104 | 48 |
| CC-HO-004 | Mouse Pad | Home and Office | $178.99 | $62.88 | Chapel Street Goods | one size | 212 | 48 |
| CC-HO-005 | Coasters Set | Home and Office | $51.99 | $17.26 | Chapel Street Goods | one size | 122 | 72 |
| CC-HO-006 | Throw Pillow | Home and Office | $148.99 | $48.68 | Chapel Street Goods | one size | 132 | 60 |
| CC-HO-007 | Wall Flag | Home and Office | $118.99 | $48.57 | Chapel Street Goods | one size | 164 | 72 |
| CC-HO-008 | Garden Flag | Home and Office | $44.99 | $14.70 | Chapel Street Goods | one size | 186 | 60 |
| CC-HO-009 | License Plate Frame | Home and Office | $45.99 | $17.24 | Chapel Street Goods | one size | 121 | 72 |
| CC-HO-010 | Clock | Home and Office | $174.99 | $69.65 | Chapel Street Goods | one size | 217 | 48 |
| CC-GF-001 | Ceramic Ornament | Gifts | $12.99 | $5.18 | East Rock Ceramics | one size | 7 | 36 |
| CC-GF-002 | Candle | Gifts | $45.99 | $18.91 | East Rock Ceramics | one size | 44 | 60 |
| CC-GF-003 | Bottle Opener | Gifts | $15.99 | $5.21 | East Rock Ceramics | one size | 79 | 24 |
| CC-GF-004 | Cutting Board | Gifts | $48.99 | $17.48 | East Rock Ceramics | one size | 167 | 36 |
| CC-GF-005 | Salt and Pepper Set | Gifts | $57.99 | $19.69 | East Rock Ceramics | one size | 94 | 24 |
| CC-GF-006 | Cookie Jar | Gifts | $49.99 | $20.06 | East Rock Ceramics | one size | 185 | 48 |
| CC-GF-007 | Bulldog Figurine | Gifts | $38.99 | $13.60 | East Rock Ceramics | one size | 124 | 48 |
| CC-GF-008 | Snow Globe | Gifts | $54.99 | $18.78 | East Rock Ceramics | one size | 160 | 24 |
| CC-PT-001 | Dog Leash | Pet Gear | $18.99 | $7.81 | Westville Bag Co | one size | 134 | 24 |
| CC-PT-002 | Dog Hoodie | Pet Gear | $15.99 | $6.37 | Westville Bag Co | one size | 198 | 36 |
| CC-PT-003 | Pet Bowl | Pet Gear | $34.99 | $13.35 | Westville Bag Co | one size | 183 | 36 |
| CC-PT-004 | Dog Toy Bone | Pet Gear | $18.99 | $6.41 | Westville Bag Co | one size | 80 | 60 |
| CC-PT-005 | Cat Collar | Pet Gear | $26.99 | $10.04 | Westville Bag Co | one size | 25 | 72 |
| CC-PT-006 | Dog Jersey | Pet Gear | $32.99 | $12.08 | Westville Bag Co | one size | 171 | 72 |

## 10. Recent purchase orders (last 12 months)

| PO | Date | Vendor | SKU | Units | Unit cost paid | Arrived on time? |
|---|---|---|---|---|---|---|
| PO-2600 | 2026-06-19 | Chapel Street Goods | CC-AC-010 | 72 | $7.02 | yes |
| PO-2601 | 2026-07-06 | Elm City Screenprint | CC-TE-013 | 300 | $9.57 | yes |
| PO-2602 | 2026-05-06 | Chapel Street Goods | CC-HO-002 | 72 | $62.46 | 5 days late |
| PO-2603 | 2026-08-07 | Elm City Screenprint | CC-TE-014 | 200 | $8.44 | yes |
| PO-2604 | 2026-01-08 | Chapel Street Goods | CC-HO-003 | 120 | $13.22 | 2 days late |
| PO-2605 | 2025-12-21 | Westville Bag Co | CC-PT-004 | 144 | $6.12 | yes |
| PO-2606 | 2026-02-22 | Blue Hen Apparel | CC-OW-004 | 96 | $53.64 | 5 days late |
| PO-2607 | 2026-03-11 | Long Wharf Knitting | CC-KN-003 | 96 | $10.47 | yes |
| PO-2608 | 2026-06-16 | Westville Bag Co | CC-PT-005 | 72 | $8.97 | 5 days late |
| PO-2609 | 2026-08-12 | Chapel Street Goods | CC-AC-007 | 144 | $1.98 | yes |
| PO-2610 | 2026-08-16 | Long Wharf Knitting | CC-KN-004 | 96 | $31.67 | yes |
| PO-2611 | 2026-02-26 | Westville Bag Co | CC-PT-001 | 240 | $7.25 | yes |
| PO-2612 | 2025-12-24 | Long Wharf Knitting | CC-KN-003 | 240 | $9.85 | yes |
| PO-2613 | 2026-01-08 | Harbor Stitch Embroidery | CC-HT-002 | 144 | $10.24 | yes |
| PO-2614 | 2026-04-23 | Blue Hen Apparel | CC-HD-001 | 200 | $28.71 | yes |
| PO-2615 | 2026-06-13 | Blue Hen Apparel | CC-HD-007 | 300 | $22.50 | 2 days late |
| PO-2616 | 2025-11-25 | Harbor Stitch Embroidery | CC-HT-007 | 144 | $9.20 | yes |
| PO-2617 | 2026-02-05 | East Rock Ceramics | CC-GF-008 | 120 | $16.58 | yes |
| PO-2618 | 2026-08-18 | Blue Hen Apparel | CC-BT-007 | 300 | $10.32 | 5 days late |
| PO-2619 | 2026-01-14 | Blue Hen Apparel | CC-OW-002 | 96 | $38.35 | 2 days late |
| PO-2620 | 2025-11-11 | Blue Hen Apparel | CC-HD-012 | 144 | $23.40 | yes |
| PO-2621 | 2026-09-26 | York Street Headwear | CC-HW-003 | 120 | $6.92 | yes |
| PO-2622 | 2026-04-22 | Blue Hen Apparel | CC-CR-001 | 200 | $16.74 | yes |
| PO-2623 | 2026-04-22 | East Rock Ceramics | CC-GL-007 | 200 | $8.98 | yes |
| PO-2624 | 2025-12-07 | Elm City Screenprint | CC-TE-001 | 200 | $11.37 | yes |
| PO-2625 | 2026-02-11 | Chapel Street Goods | CC-AC-003 | 96 | $4.12 | 5 days late |
| PO-2626 | 2026-01-01 | Maple Leaf Mills | CC-WV-004 | 200 | $30.85 | yes |
| PO-2627 | 2026-09-05 | Blue Hen Apparel | CC-CR-003 | 120 | $19.29 | 5 days late |
| PO-2628 | 2025-11-21 | East Rock Ceramics | CC-GF-001 | 144 | $4.74 | yes |
| PO-2629 | 2026-05-06 | Elm City Screenprint | CC-TE-011 | 300 | $10.35 | yes |
| PO-2630 | 2026-01-09 | East Rock Ceramics | CC-GL-005 | 96 | $7.99 | yes |
| PO-2631 | 2026-07-14 | Blue Hen Apparel | CC-QZ-004 | 200 | $33.28 | yes |
| PO-2632 | 2026-08-10 | Harbor Stitch Embroidery | CC-PO-005 | 200 | $18.79 | yes |
| PO-2633 | 2026-07-08 | Chapel Street Goods | CC-AC-010 | 200 | $7.21 | 2 days late |
| PO-2634 | 2025-11-10 | York Street Headwear | CC-HW-001 | 240 | $9.23 | yes |
| PO-2635 | 2026-04-02 | Chapel Street Goods | CC-AC-008 | 300 | $8.58 | yes |
| PO-2636 | 2026-07-27 | Chapel Street Goods | CC-HO-005 | 200 | $15.46 | 2 days late |
| PO-2637 | 2026-02-03 | Chapel Street Goods | CC-HO-008 | 72 | $12.94 | yes |
| PO-2638 | 2026-05-26 | East Rock Ceramics | CC-GF-007 | 300 | $12.87 | yes |
| PO-2639 | 2026-06-09 | Maple Leaf Mills | CC-WV-002 | 200 | $49.28 | 5 days late |

## 11. Brand and quality checklist

- Bulldog Blue must match Pantone 289 C. Reject samples that look purple or teal.
- The Y logo and the Handsome Dan art come only from the licensed art files. No redraws.
- Print must survive 30 washes with no cracking. Embroidery must have no loose threads over 3mm.
- Every garment carries the Campus Customs neck label and the licensing hangtag.
- Mugs and glassware pass a dishwasher test before we accept the first case.

## 12. Big-weekend planning

Plan reorders backward from the event. For Parents Weekend we want stock on the shelf 7 days before the
weekend, so a 21-day lead time quote must be signed by early September. For The Game we double hoodie,
crewneck, scarf, and hat stock. For Commencement we double tees, mugs, and frames, and we add Class of
banners. When two approved vendors can make the same item, prefer the one that is cheaper per unit after
shipping, unless the cheaper vendor missed a deadline in the last 12 months.

## 13. How the vendor desk agent should report

For each vendor document, report: vendor name, the Campus Customs SKU, the quoted unit price, the lead time
in days, the minimum order in units, the decision (recommend or do_not_recommend), and a one-sentence
reason that names the purchasing check that decided it.
